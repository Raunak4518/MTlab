from __future__ import annotations

import argparse
import pickle
import time
from pathlib import Path

import mlflow

from mtlab.experiments.tracking import start_experiment_run, log_dataset_info
from mtlab.smt.nltk_alignment import train_nltk_ibm


def main():
    parser = argparse.ArgumentParser(description="Pure-Python NLTK IBM4/IBM5 reference training (small subsets only).")
    parser.add_argument("--project-root", default=".")
    parser.add_argument("--train-en", default="data/processed/samanantar/en-hi/word/train.en")
    parser.add_argument("--train-hi", default="data/processed/samanantar/en-hi/word/train.hi")
    parser.add_argument("--model", choices=["ibm4", "ibm5"], required=True)
    parser.add_argument("--direction", choices=["en-hi", "hi-en"], default="en-hi")
    parser.add_argument("--max-pairs", type=int, default=300)
    parser.add_argument("--iterations", type=int, default=1)
    parser.add_argument("--output-dir", default="artifacts/ibm_nltk")
    args = parser.parse_args()

    root = Path(args.project_root).resolve()
    en_path = root / args.train_en
    hi_path = root / args.train_hi
    if args.direction == "en-hi":
        source, target = en_path, hi_path
    else:
        source, target = hi_path, en_path

    output_dir = root / args.output_dir / args.model / args.direction
    output_dir.mkdir(parents=True, exist_ok=True)
    model_path = output_dir / "model.pkl"
    alignment_path = output_dir / "alignments.pharaoh"

    with start_experiment_run(
        "01-word-alignment", f"nltk-{args.model}-{args.direction}-reference",
        params={
            "engine": "NLTK", "model": args.model.upper(),
            "direction": args.direction, "max_pairs": args.max_pairs,
            "iterations": args.iterations,
            "word_classes": "frequency-rank approximation",
            "dataset_scope": "small-reference-subset",
        },
        tags={"research_area": "word-alignment", "engine": "nltk", "model": args.model,
              "direction": args.direction, "dataset_scope": "small-reference-subset"},
    ):
        started = time.perf_counter()
        model, alignments, src_lines, tgt_lines = train_nltk_ibm(
            source, target, args.model, args.iterations, args.max_pairs
        )
        elapsed = time.perf_counter() - started
        with model_path.open("wb") as f:
            pickle.dump(model, f, protocol=pickle.HIGHEST_PROTOCOL)
        with alignment_path.open("w", encoding="utf-8") as f:
            for links in alignments:
                f.write(" ".join(f"{i}-{j}" for i, j in sorted(links)) + "\n")
        mlflow.log_metrics({
            "training_seconds": elapsed,
            "training_pairs": len(src_lines),
            "training_pairs_per_second": len(src_lines) / max(elapsed, 1),
        })
        log_dataset_info("train", "Samanantar", "train-subset", len(src_lines), source.parent)
        mlflow.log_artifact(str(model_path))
        mlflow.log_artifact(str(alignment_path))
    print(f"Saved NLTK {args.model.upper()} model to {model_path}")
    print(f"Saved Pharaoh alignments to {alignment_path}")
    print("Note: use MGIZA++ for full-corpus IBM4/IBM5; NLTK is a small-subset reference implementation.")


if __name__ == "__main__":
    main()
